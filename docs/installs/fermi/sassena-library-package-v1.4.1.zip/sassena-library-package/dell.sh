PREFIX=$HOME/myroot3
SRCDIR=$HOME/src


mkdir -p $SRCDIR
mkdir -p $PREFIX
OLDDIR=`pwd`
cd $SRCDIR

export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:/usr/lib64

module load openmpi/gcc/64/1.3.3
module load acml/gcc/64/4.3.0
module load lapack/gcc/64/3.2.1

export LD_LIBRARY_PATH=$PREFIX/lib:${LD_LIBRARY_PATH}
export PATH=$PREFIX/bin:${PATH}

# download BOOST library. (need to use 1.43 for sassena v1.2.1)
wget http://downloads.sourceforge.net/project/boost/boost/1.47.0/boost_1_47_0.tar.gz
#wget http://downloads.sourceforge.net/project/boost/boost/1.43.0/boost_1_43_0.tar.gz
tar -xzf boost_1_47_0.tar.gz
#tar -xzf boost_1_43_0.tar.gz
cd boost_1_47_0
#cd boost_1_43_0
./bootstrap.sh
echo "using mpi ; " >> project-config.jam
# use b2 for >1.43, bjam for <=1.43
#./b2 --prefix=${HOME}/myroot install
./b2 --prefix=$PREFIX install
# if b2/bjam produces a message like:
# MPI auto-detection failed: unknown wrapper compiler mpic++
# you probably have forgotten to initialize your MPI environment (see above)
cd ..

wget ftp://xmlsoft.org/libxml2/libxml2-2.7.8.tar.gz
tar -xzf libxml2-2.7.8.tar.gz 
cd libxml2-2.7.8
./configure --prefix=$PREFIX
make && make install
cd ..

# download and install cmake
wget http://www.cmake.org/files/v2.8/cmake-2.8.6.tar.gz
tar -xzf cmake-2.8.6.tar.gz
cd cmake-2.8.6
./configure --prefix=$PREFIX
gmake && gmake install
cd ..

# download and install hdf5
wget http://www.hdfgroup.org/ftp/HDF5/releases/hdf5-1.8.7/src/hdf5-1.8.7.tar.gz
tar -xzf hdf5-1.8.7.tar.gz
cd hdf5-1.8.7
./configure --prefix=$PREFIX
make && make install
cd ..

# or: build your own FFTW3
wget http://www.fftw.org/fftw-3.3.tar.gz
tar -xzf fftw-3.3.tar.gz
cd fftw-3.3
./configure --prefix=$PREFIX
make && make install
./configure --prefix=$PREFIX --enable-shared
make clean && make && make install
cd ..
export FFTW3_HOME=$PREFIX

# set the BOOST environment
export BOOST_ROOT=$PREFIX
export HDF5_HOME=$PREFIX

# compile sassena (presumes you have copied the tarball to $HOME)
cd $OLDDIR
mkdir -p builds/v1.4.0 && cd builds/v1.4.0
cmake -DCMAKE_INSTALL_PREFIX=$PREFIX ../..
make && make install