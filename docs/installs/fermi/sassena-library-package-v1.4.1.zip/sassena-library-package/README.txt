Content, Installation and Testing Instructions
==============================================

CONTENT
=======
The package contains the following files:
1. sassena-v1.4.1.tar.gz
contains the source code for the software sassena

2. filemap-sassena-v1.4.1.zip
contains description of the source code directory structure and the modularity of the software

3. sassena-docs-v1.4.1.zip + sassena-doxyfile
contains source code documentation and the project file for generating the source code docs

4. logo.png 
Sassena logo image file

5. test-waterdyn4.tar.gz
test package for the software sassena, including:
- database 
- configuration files for computing the incoherent scattering
- MD simulation data
- example output
- support scripts (require additional dependencies, e.g. h5py)

6. dell.sh 
Sample install instructions, provided as an executable shell script

7. config-doc-v1.4.0-rev4.pdf
Configuration File Reference. v1.4.1 is the same as v1.4.0. Minor version updates don't change anything with respect to the configuration file.

INSTALLATION
============

1. Dependencies
Sassena requires the following libraries:

Boost Libraries
FFTW3
GIT
CMake
GNU C++ Compiler
MPI (e.g. openmpi)
LibXML
LAPACK
HDF5

Some of these dependencies come preinstalled on most platforms (e.g. LibXML, LAPACK, MPI, C++ Compiler, CMake, FFTW3). Git is only required if the source code is to be downloaded through the git repository.

Usually HDF5 and the Boost Libraries have to be installed manually. The sample script contains instructions for downloading and compiling these support libraries.

Also there may be multiple version of the support library available on the target platform which may or may not full fill the requirements of the software sassena. (E.g. a shared library compiled version of sassena requires fftw3 shared library support. 

2. Instructions

The following instructions are specific to a DELL computer cluster cluster (http://dellmaster1.qub.ac.uk/wiki/)

2.1. add the following to your shell startup file ($HOME/.bashrc) on the target cluster (dell), and login again

module load gcc
module add shared torque maui

2.2. make the sassena source code available, e.g:

scp sassena-v1.4.1.tar.gz dellmaster1.qub.ac.uk:

2.3. make the install script available, e.g:

scp dell.sh dellmaster1.qub.ac.uk:

Look at the shell script and make adjustments to the following variables: $PREFIX, $SRCDIR
The $PREFIX holds the dependencies and the $SRCDIR is a working directory for temporary downloads and the compilation of the dependencies. Once they are installed into the target directory ($PREFIX), the contents of $SRCDIR can be deleted.

2.4 uncompress the sassena source code package
tar -xzf sassena-v1.4.1.tar.gz
cd sassena-v1.4.1

2.5 execute the shell script from within the source code directory
bash ../dell.sh

this will create download, compile and install all the dependencies and compile the sassena source code in the subdirectory builds/v1.4.1, which also holds the binary "sassena"

TESTING
============

1. make the testing package available, e.g:

scp test-waterdyn4.tar.gz dellmaster1.qub.ac.uk:

2. uncompress the testing package and change directories

tar -xzf test-waterdyn4.tar.gz
cd test-waterdyn4

3. call the sassena binary from within the test directory, e.g.

../sassena-v1.4.1/builds/v1.4.1/sassena
or to run in parallel:
mpirun -np 2 ../sassena-v1.4.1/builds/v1.4.1/sassena


if you get error messages, make sure you have loaded the correct modules for your platform

4. The sassena binary will run (hopefully) and produce an output file "signal.h5", which contains the scattering signal. You can inspect the contents of this file by using 'h5ls' or 'h5dump', which are part of the HDF5 suite and should be available in the bin folder of the dependencies. E.g use the following command to show the datasets contained in signal.h5:

../myroot3/bin/h5ls signal.h5

The full (dynamic) signal is contained in the dataset "fqt".
Use h5dump to extract the text representation of the scattering signal:

../myroot3/bin/h5dump -d fqt -y -o fqt.txt signal.h5

This writes the real and the imaginary parts of the scattering function F(q,t) to the text file "fqt.txt", where each line represents a consecutive time step. 

You can compare the output to a control calculation:

diff fqt.txt output/fqt-1.txt

which should only show differences due to machine dependent floating point impression.

5. You're done. Have fun.

FURTHER NOTES
=====

keep up to date: http://www.sassena.org
find documentation: http://www.sassena.org/documentation
become part of the user community: http://forum.sassena.org/
report bugs and provide feedback: http://bugzilla.sassena.org/

if all else fails: ben@sassena.org, ben@benlabs.net, lindnerb@ornl.gov, blindne1@utk.edu